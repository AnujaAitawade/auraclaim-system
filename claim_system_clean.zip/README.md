# AuraClaim - Health Insurance Claim System
### Built with Django 6.0 & Tkinter Desktop GUI

**AuraClaim** is an enterprise-grade Health Insurance Claim Management System featuring a **dual-interface architecture**:
1. **Django Web Application**: A modern, responsive web portal for Patients, Hospitals, and Insurance Adjudicators accessible via any web browser.
2. **Tkinter Desktop Client**: A high-performance Python desktop application for hospital billing desks and insurance claims officers with real-time API synchronization.

---

## Architecture Overview

```
                      ┌──────────────────────────────────────┐
                      │    Django Web Platform (Port 8000)   │
                      │  • Role-Based Auth & Session Engine  │
                      │  • Claims & Policy Data Models (ORM) │
                      │  • Tailwind CSS Web Templates        │
                      │  • File Uploads & Audit Timeline     │
                      │  • JSON / REST API Endpoints         │
                      └──────────────────┬───────────────────┘
                                         │
                 ┌───────────────────────┴───────────────────────┐
                 │                                               │
                 ▼                                               ▼
     ┌───────────────────────┐                       ┌───────────────────────┐
     │    Web Browser UI     │                       │ Tkinter Desktop Client│
     │  (Chrome / Edge / FF) │                       │  (Native Windows GUI) │
     │  • http://127.0.0.1   │                       │  • python             │
     │  • Patients & Public  │                       │    tkinter_client.py  │
     └───────────────────────┘                       └───────────────────────┘
```

---

## Quick Start Guide

### 1. Master Interactive Launcher (Recommended)
You can launch everything using the interactive runner:
```bash
python run_portal.py
```
This lets you select:
- `1`: Start Django Web Server
- `2`: Launch Tkinter Desktop Client
- `3`: Launch **BOTH** (starts Django in the background and opens the desktop app)
- `4`: Reset / Seed demo data
- `5`: Run test suite

---

### 2. Manual Commands

#### Start the Django Web Portal:
```bash
python manage.py runserver
```
Then open: **[http://127.0.0.1:8000](http://127.0.0.1:8000)**

#### Launch the Tkinter Desktop Application:
*(In a separate terminal or while server is running)*
```bash
python tkinter_client.py
```

#### Run Automated Test Suite:
```bash
python manage.py test
```

---

## Pre-Configured Demo Accounts

All test accounts use the password: `demo1234`

| Role | Username | Password | Key Capabilities |
| :--- | :--- | :--- | :--- |
| **Patient** | `patient_demo` | `demo1234` | View policy limits, file claims, upload invoices, respond to info requests |
| **Hospital** | `hospital_demo` | `demo1234` | Submit clinical treatment claims, upload bills & discharge summaries |
| **Insurer** | `insurer_demo` | `demo1234` | Review claims, issue new insurance policies, approve/reject/settle payouts |
| **Superuser** | `admin` | `admin1234` | Access Django Admin at `/admin/` |

*(To re-seed fresh sample data anytime, click the "Seed Demo Data" button on the web portal or run option `4` in `run_portal.py`)*

---

## Key Features

- **Role-Based Portals**: Tailored views and permissions for Patients, Hospitals, and Insurance adjudicators.
- **Claim Workflow State Machine**: Validates transitions:
  - `Submitted` ➔ `Under Review` or `Rejected`
  - `Under Review` ➔ `Info Requested`, `Approved`, or `Rejected`
  - `Info Requested` ➔ Patient/Hospital submits response ➔ returns to `Under Review`
  - `Approved` ➔ `Settled` (automatically deducts payout from policy balance)
- **Document Management**: Attach and download medical bills, discharge summaries, and ID proofs.
- **Audit History**: Complete chronological history of status changes, remarks, and adjudicators.
- **Operational Analytics Dashboard**: Real-time throughput telemetry tracking total claim counts, adjudication approval rate (%), and average turnaround processing time (days/hours) across Web and Desktop interfaces.
- **REST / JSON API**: Built-in endpoints enabling the Tkinter desktop client (and third-party systems) to query live analytics stats, view claims, submit claims, and update review statuses.

---

## File Structure

```
claim-system/
├── manage.py                  # Django management script
├── run_portal.py              # Interactive multi-process launcher
├── tkinter_client.py          # Standalone Tkinter desktop GUI app
├── claim_portal/              # Django project settings & root URLs
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── claims/                    # Core Django application
│   ├── models.py              # UserProfile, Policy, Claim, ClaimDocument, ClaimStatusHistory
│   ├── views.py               # Web views and JSON REST API handlers
│   ├── forms.py               # Model forms and validation rules
│   ├── urls.py                # Routing for Web pages & API endpoints
│   ├── admin.py               # Django Admin configuration
│   └── tests.py               # 7 automated unit & integration tests
├── templates/                 # Tailwind CSS HTML templates
│   ├── base.html              # Modern responsive navbar, flash alerts, footer
│   └── claims/
│       ├── landing.html       # Landing page with demo autofill
│       ├── login.html         # Login screen with role buttons
│       ├── register.html      # Multi-role registration
│       ├── dashboard.html     # Statistics, policies, search, claims table
│       ├── claim_detail.html  # Claim inspector, adjudicator console, audit trail
│       ├── claim_form.html    # Medical claim submission form
│       ├── policy_list.html   # Active policies directory
│       └── policy_form.html   # Issue policy form (insurer)
└── media/                     # Uploaded medical invoices and documents
```
