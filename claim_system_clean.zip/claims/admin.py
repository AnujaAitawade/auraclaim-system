from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import UserProfile, Policy, Claim, ClaimDocument, ClaimStatusHistory


class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile Info'


class UserAdmin(BaseUserAdmin):
    inlines = (UserProfileInline,)
    list_display = ('username', 'email', 'first_name', 'last_name', 'get_role', 'is_staff')

    def get_role(self, instance):
        if hasattr(instance, 'profile'):
            return instance.profile.get_role_display()
        return '-'
    get_role.short_description = 'Role'


admin.site.unregister(User)
admin.site.register(User, UserAdmin)


@admin.register(Policy)
class PolicyAdmin(admin.ModelAdmin):
    list_display = ('policy_number', 'patient', 'coverage_amount', 'claimed_amount', 'remaining_amount', 'status', 'start_date', 'end_date')
    list_filter = ('status', 'start_date', 'end_date')
    search_fields = ('policy_number', 'patient__username', 'patient__email', 'patient__first_name', 'patient__last_name')


class ClaimDocumentInline(admin.TabularInline):
    model = ClaimDocument
    extra = 0
    readonly_fields = ('uploaded_at', 'uploaded_by')


class ClaimStatusHistoryInline(admin.TabularInline):
    model = ClaimStatusHistory
    extra = 0
    readonly_fields = ('changed_at', 'changed_by')


@admin.register(Claim)
class ClaimAdmin(admin.ModelAdmin):
    list_display = ('claim_number', 'patient', 'policy', 'claim_amount', 'approved_amount', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('claim_number', 'patient__username', 'policy__policy_number', 'diagnosis')
    inlines = [ClaimDocumentInline, ClaimStatusHistoryInline]


@admin.register(ClaimDocument)
class ClaimDocumentAdmin(admin.ModelAdmin):
    list_display = ('file_name', 'claim', 'doc_type', 'uploaded_by', 'uploaded_at')
    list_filter = ('doc_type', 'uploaded_at')
    search_fields = ('file_name', 'claim__claim_number')


@admin.register(ClaimStatusHistory)
class ClaimStatusHistoryAdmin(admin.ModelAdmin):
    list_display = ('claim', 'status', 'changed_by', 'changed_at', 'remarks')
    list_filter = ('status', 'changed_at')
