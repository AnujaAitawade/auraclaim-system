from django import forms
from django.contrib.auth.models import User
from .models import UserProfile, Policy, Claim, ClaimDocument


class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-input', 'placeholder': 'Password (min 6 characters)'}), min_length=6)
    role = forms.ChoiceField(choices=UserProfile.ROLE_CHOICES, widget=forms.Select(attrs={'class': 'form-input'}))
    organization_name = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Hospital or Organization name (if applicable)'}))
    phone = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Phone number'}))
    address = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Street address'}))

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Username'}),
            'first_name': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'First Name'}),
            'last_name': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Last Name'}),
            'email': forms.EmailInput(attrs={'class': 'form-input', 'placeholder': 'Email address'}),
        }


class PolicyForm(forms.ModelForm):
    patient_email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-input', 'placeholder': 'Patient email'}))

    class Meta:
        model = Policy
        fields = ['policy_number', 'coverage_amount', 'start_date', 'end_date', 'status']
        widgets = {
            'policy_number': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'e.g. POL-89024'}),
            'coverage_amount': forms.NumberInput(attrs={'class': 'form-input', 'placeholder': 'e.g. 50000.00'}),
            'start_date': forms.DateInput(attrs={'class': 'form-input', 'type': 'date'}),
            'end_date': forms.DateInput(attrs={'class': 'form-input', 'type': 'date'}),
            'status': forms.Select(attrs={'class': 'form-input'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        start = cleaned_data.get('start_date')
        end = cleaned_data.get('end_date')
        email = cleaned_data.get('patient_email')

        if start and end and end < start:
            raise forms.ValidationError("End date cannot be prior to start date.")

        if email:
            try:
                patient = User.objects.get(email=email)
                cleaned_data['patient'] = patient
            except User.DoesNotExist:
                raise forms.ValidationError(f"No user found with email '{email}'. Patient must register first.")
        return cleaned_data


class ClaimForm(forms.ModelForm):
    class Meta:
        model = Claim
        fields = ['policy', 'diagnosis', 'treatment_details', 'admission_date', 'discharge_date', 'claim_amount']
        widgets = {
            'policy': forms.Select(attrs={'class': 'form-input'}),
            'diagnosis': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'e.g. Acute Appendectomy'}),
            'treatment_details': forms.Textarea(attrs={'class': 'form-input', 'rows': 3, 'placeholder': 'Clinical summary, surgery details, medication'}),
            'admission_date': forms.DateInput(attrs={'class': 'form-input', 'type': 'date'}),
            'discharge_date': forms.DateInput(attrs={'class': 'form-input', 'type': 'date'}),
            'claim_amount': forms.NumberInput(attrs={'class': 'form-input', 'placeholder': '0.00'}),
        }

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user:
            profile = getattr(user, 'profile', None)
            if profile and profile.role == 'patient':
                self.fields['policy'].queryset = Policy.objects.filter(patient=user, status='active')
            else:
                self.fields['policy'].queryset = Policy.objects.filter(status='active')

    def clean(self):
        cleaned_data = super().clean()
        policy = cleaned_data.get('policy')
        claim_amount = cleaned_data.get('claim_amount')
        adm = cleaned_data.get('admission_date')
        dis = cleaned_data.get('discharge_date')

        if adm and dis and dis < adm:
            raise forms.ValidationError("Discharge date cannot be before admission date.")

        if policy and claim_amount:
            if claim_amount <= 0:
                raise forms.ValidationError("Claim amount must be greater than zero.")
            if claim_amount > policy.remaining_amount:
                raise forms.ValidationError(
                    f"Claim amount (${claim_amount:,.2f}) exceeds policy remaining balance (${policy.remaining_amount:,.2f})."
                )
        return cleaned_data


class ClaimDocumentForm(forms.ModelForm):
    class Meta:
        model = ClaimDocument
        fields = ['doc_type', 'file']
        widgets = {
            'doc_type': forms.Select(attrs={'class': 'form-input'}),
            'file': forms.FileInput(attrs={'class': 'form-input'}),
        }
