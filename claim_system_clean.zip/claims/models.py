from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from decimal import Decimal
import uuid


class UserProfile(models.Model):
    ROLE_CHOICES = (
        ('patient', 'Patient'),
        ('hospital', 'Hospital Provider'),
        ('insurer', 'Insurance Officer / Insurer'),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='patient')
    phone = models.CharField(max_length=20, blank=True)
    address = models.CharField(max_length=255, blank=True)
    organization_name = models.CharField(
        max_length=150, 
        blank=True, 
        help_text="Name of hospital or insurer agency if applicable"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        org = f" ({self.organization_name})" if self.organization_name else ""
        return f"{self.user.get_full_name() or self.user.username} [{self.get_role_display()}]{org}"

    @property
    def display_name(self):
        if self.role == 'hospital' and self.organization_name:
            return self.organization_name
        return self.user.get_full_name() or self.user.username


class Policy(models.Model):
    STATUS_CHOICES = (
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('expired', 'Expired'),
    )

    policy_number = models.CharField(max_length=40, unique=True)
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='policies')
    coverage_amount = models.DecimalField(max_digits=12, decimal_places=2)
    claimed_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    start_date = models.DateField()
    end_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = "Policies"

    def __str__(self):
        return f"{self.policy_number} - {self.patient.get_full_name() or self.patient.username}"

    @property
    def remaining_amount(self):
        rem = self.coverage_amount - self.claimed_amount
        return max(Decimal('0.00'), rem)

    @property
    def is_current(self):
        today = timezone.now().date()
        return self.status == 'active' and self.start_date <= today <= self.end_date


class Claim(models.Model):
    STATUS_SUBMITTED = 'Submitted'
    STATUS_UNDER_REVIEW = 'Under Review'
    STATUS_INFO_REQUESTED = 'Info Requested'
    STATUS_APPROVED = 'Approved'
    STATUS_REJECTED = 'Rejected'
    STATUS_SETTLED = 'Settled'

    STATUS_CHOICES = (
        (STATUS_SUBMITTED, 'Submitted'),
        (STATUS_UNDER_REVIEW, 'Under Review'),
        (STATUS_INFO_REQUESTED, 'Info Requested'),
        (STATUS_APPROVED, 'Approved'),
        (STATUS_REJECTED, 'Rejected'),
        (STATUS_SETTLED, 'Settled'),
    )

    claim_number = models.CharField(max_length=40, unique=True, blank=True)
    policy = models.ForeignKey(Policy, on_delete=models.CASCADE, related_name='claims')
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='patient_claims')
    hospital = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='hospital_claims'
    )
    diagnosis = models.CharField(max_length=255)
    treatment_details = models.TextField(blank=True)
    admission_date = models.DateField()
    discharge_date = models.DateField()
    claim_amount = models.DecimalField(max_digits=12, decimal_places=2)
    approved_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default=STATUS_SUBMITTED)
    insurer_remarks = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.claim_number} - {self.patient.username} (${self.claim_amount})"

    def save(self, *args, **kwargs):
        if not self.claim_number:
            self.claim_number = f"CLM-{uuid.uuid4().hex[:8].upper()}"
        super().save(*args, **kwargs)

    @property
    def next_possible_statuses(self):
        transitions = {
            self.STATUS_SUBMITTED: [self.STATUS_UNDER_REVIEW, self.STATUS_REJECTED],
            self.STATUS_UNDER_REVIEW: [self.STATUS_INFO_REQUESTED, self.STATUS_APPROVED, self.STATUS_REJECTED],
            self.STATUS_INFO_REQUESTED: [self.STATUS_UNDER_REVIEW, self.STATUS_REJECTED],
            self.STATUS_APPROVED: [self.STATUS_SETTLED],
            self.STATUS_REJECTED: [],
            self.STATUS_SETTLED: [],
        }
        return transitions.get(self.status, [])


class ClaimDocument(models.Model):
    DOC_TYPES = (
        ('bill', 'Hospital Bill / Invoice'),
        ('discharge_summary', 'Discharge Summary'),
        ('id_proof', 'Government ID Proof'),
        ('medical_report', 'Diagnostic / Medical Report'),
        ('other', 'Other Supporting Document'),
    )

    claim = models.ForeignKey(Claim, on_delete=models.CASCADE, related_name='documents')
    doc_type = models.CharField(max_length=30, choices=DOC_TYPES)
    file = models.FileField(upload_to='claims/documents/%Y/%m/')
    file_name = models.CharField(max_length=255)
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.get_doc_type_display()} - {self.file_name}"

    def save(self, *args, **kwargs):
        if not self.file_name and self.file:
            self.file_name = self.file.name.split('/')[-1].split('\\')[-1]
        super().save(*args, **kwargs)


class ClaimStatusHistory(models.Model):
    claim = models.ForeignKey(Claim, on_delete=models.CASCADE, related_name='history')
    status = models.CharField(max_length=30)
    remarks = models.TextField(blank=True)
    changed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['changed_at']
        verbose_name_plural = "Claim status histories"

    def __str__(self):
        return f"{self.claim.claim_number} -> {self.status} at {self.changed_at}"
