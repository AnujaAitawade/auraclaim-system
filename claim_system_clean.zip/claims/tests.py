from django.test import TestCase, Client
from django.contrib.auth.models import User
from decimal import Decimal
from django.utils import timezone
import datetime as dt
from .models import UserProfile, Policy, Claim, ClaimStatusHistory


class ClaimSystemTests(TestCase):
    def setUp(self):
        self.client = Client()
        today = timezone.now().date()

        # Insurer
        self.insurer = User.objects.create_user(username='test_insurer', email='ins@test.com', password='password123')
        UserProfile.objects.create(user=self.insurer, role='insurer', organization_name='Test Shield')

        # Patient
        self.patient = User.objects.create_user(username='test_patient', email='pat@test.com', password='password123')
        UserProfile.objects.create(user=self.patient, role='patient')

        # Policy
        self.policy = Policy.objects.create(
            policy_number='POL-TEST-001',
            patient=self.patient,
            coverage_amount=Decimal('10000.00'),
            claimed_amount=Decimal('0.00'),
            start_date=today - dt.timedelta(days=10),
            end_date=today + dt.timedelta(days=350),
            status='active'
        )

        # Claim
        self.claim = Claim.objects.create(
            policy=self.policy,
            patient=self.patient,
            diagnosis='Fracture treatment',
            admission_date=today - dt.timedelta(days=2),
            discharge_date=today,
            claim_amount=Decimal('1500.00'),
            status=Claim.STATUS_SUBMITTED
        )

    def test_remaining_policy_balance(self):
        self.assertEqual(self.policy.remaining_amount, Decimal('10000.00'))

    def test_claim_creation(self):
        self.assertTrue(self.claim.claim_number.startswith('CLM-'))
        self.assertEqual(self.claim.status, Claim.STATUS_SUBMITTED)

    def test_insurer_state_transitions(self):
        # 1. Submitted -> Under Review
        self.assertIn(Claim.STATUS_UNDER_REVIEW, self.claim.next_possible_statuses)
        self.assertIn(Claim.STATUS_REJECTED, self.claim.next_possible_statuses)

        self.claim.status = Claim.STATUS_UNDER_REVIEW
        self.claim.save()

        # 2. Under Review -> Approved
        self.assertIn(Claim.STATUS_APPROVED, self.claim.next_possible_statuses)
        self.assertIn(Claim.STATUS_INFO_REQUESTED, self.claim.next_possible_statuses)

    def test_api_login(self):
        res = self.client.post('/api/auth/login/', {
            'username': 'test_insurer',
            'password': 'password123'
        }, content_type='application/json')
        data = res.json()
        self.assertTrue(data.get('success'))
        self.assertEqual(data['user']['role'], 'insurer')

    def test_api_claims_list(self):
        res = self.client.get('/api/claims/')
        data = res.json()
        self.assertIn('claims', data)
        self.assertEqual(len(data['claims']), 1)
        self.assertEqual(data['claims'][0]['claim_number'], self.claim.claim_number)

    def test_api_claim_status_update(self):
        res = self.client.post(f'/api/claims/{self.claim.id}/status/', {
            'status': 'Under Review',
            'remarks': 'Reviewing medical charts'
        }, content_type='application/json')
        self.assertEqual(res.status_code, 200)
        self.claim.refresh_from_db()
        self.assertEqual(self.claim.status, 'Under Review')
        self.assertEqual(self.claim.insurer_remarks, 'Reviewing medical charts')

    def test_web_dashboard_authenticated(self):
        self.client.login(username='test_patient', password='password123')
        res = self.client.get('/dashboard/')
        self.assertEqual(res.status_code, 200)
        self.assertContains(res, 'POL-TEST-001')
        self.assertContains(res, 'Operational Claims Analytics')
        self.assertContains(res, 'Adjudication Approval Rate')

    def test_analytics_api_endpoint(self):
        # Update claim to approved
        self.claim.status = Claim.STATUS_APPROVED
        self.claim.save()
        ClaimStatusHistory.objects.create(
            claim=self.claim,
            status=Claim.STATUS_APPROVED,
            remarks="Approved"
        )
        res = self.client.get('/api/stats/')
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn('approval_rate', data)
        self.assertIn('avg_processing_time', data)
        self.assertIn('total_claims', data)
        self.assertEqual(data['approval_rate'], 100.0)
        self.assertEqual(data['approved_claims'], 1)
