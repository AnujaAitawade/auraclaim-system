from django.urls import path
from . import views

urlpatterns = [
    # Web UI
    path('', views.landing, name='landing'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('seed-demo/', views.seed_demo_data, name='seed_demo'),

    # Claims
    path('claims/new/', views.claim_create, name='claim_create'),
    path('claims/<int:pk>/', views.claim_detail, name='claim_detail'),
    path('claims/<int:pk>/status/', views.claim_status_update, name='claim_status_update'),
    path('claims/<int:pk>/respond/', views.claim_respond, name='claim_respond'),
    path('claims/<int:pk>/upload/', views.claim_document_upload, name='claim_document_upload'),

    # Policies
    path('policies/', views.policy_list, name='policy_list'),
    path('policies/new/', views.policy_create, name='policy_create'),

    # JSON API (For Tkinter Desktop client & integrations)
    path('api/auth/login/', views.api_login, name='api_login'),
    path('api/claims/', views.api_claims_list, name='api_claims_list'),
    path('api/claims/<int:pk>/', views.api_claim_detail, name='api_claim_detail'),
    path('api/claims/<int:pk>/status/', views.api_claim_status_update, name='api_claim_status_update'),
    path('api/policies/', views.api_policies_list, name='api_policies_list'),
    path('api/stats/', views.api_dashboard_stats, name='api_dashboard_stats'),
]
