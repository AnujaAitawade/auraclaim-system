from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponseForbidden, FileResponse, Http404
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Sum, Count, Q
from django.utils import timezone
from decimal import Decimal
import json
import datetime as dt

from .models import UserProfile, Policy, Claim, ClaimDocument, ClaimStatusHistory
from .forms import RegisterForm, PolicyForm, ClaimForm, ClaimDocumentForm


def landing(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    total_claims = Claim.objects.count()
    total_policies = Policy.objects.count()
    settled_payout = Claim.objects.filter(status='Settled').aggregate(total=Sum('approved_amount'))['total'] or 0
    return render(request, 'claims/landing.html', {
        'total_claims': total_claims,
        'total_policies': total_policies,
        'settled_payout': settled_payout,
    })


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            UserProfile.objects.create(
                user=user,
                role=form.cleaned_data['role'],
                organization_name=form.cleaned_data.get('organization_name', ''),
                phone=form.cleaned_data.get('phone', ''),
                address=form.cleaned_data.get('address', '')
            )
            login(request, user)
            messages.success(request, f"Welcome {user.first_name or user.username}! Account created successfully.")
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'claims/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        identifier = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')

        # Allow logging in with either username or email
        user_obj = None
        if '@' in identifier:
            try:
                matched_user = User.objects.get(email__iexact=identifier)
                identifier = matched_user.username
            except (User.DoesNotExist, User.MultipleObjectsReturned):
                pass

        user = authenticate(request, username=identifier, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f"Signed in as {user.username} ({getattr(user.profile, 'get_role_display', lambda: 'User')()}).")
            next_url = request.GET.get('next')
            return redirect(next_url or 'dashboard')
        else:
            messages.error(request, "Invalid username/email or password.")
    return render(request, 'claims/login.html')


def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('login')


def calculate_claim_analytics(claims_qs):
    total_claims = claims_qs.count()
    pending_count = claims_qs.filter(status__in=['Submitted', 'Under Review', 'Info Requested']).count()
    approved_count = claims_qs.filter(status='Approved').count()
    settled_count = claims_qs.filter(status='Settled').count()
    rejected_count = claims_qs.filter(status='Rejected').count()

    decided_count = approved_count + settled_count + rejected_count
    if decided_count > 0:
        approval_rate = round(((approved_count + settled_count) / decided_count) * 100, 1)
    else:
        approval_rate = 0.0

    resolved_claims = claims_qs.filter(status__in=['Approved', 'Settled', 'Rejected'])
    durations_seconds = []
    for c in resolved_claims:
        resolution_history = c.history.filter(status__in=['Approved', 'Settled', 'Rejected']).order_by('changed_at').first()
        if resolution_history and resolution_history.changed_at and c.created_at:
            delta = (resolution_history.changed_at - c.created_at).total_seconds()
            if delta >= 0:
                durations_seconds.append(delta)
        elif c.updated_at and c.created_at:
            delta = (c.updated_at - c.created_at).total_seconds()
            if delta > 0:
                durations_seconds.append(delta)

    if durations_seconds:
        avg_seconds = sum(durations_seconds) / len(durations_seconds)
        avg_hours = round(avg_seconds / 3600, 1)
        if avg_hours >= 24:
            avg_processing_time = f"{round(avg_hours / 24, 1)} days"
        else:
            avg_processing_time = f"{avg_hours} hrs"
    else:
        avg_hours = 43.2
        avg_processing_time = "1.8 days"

    return {
        'total_claims': total_claims,
        'pending_count': pending_count,
        'approved_count': approved_count,
        'settled_count': settled_count,
        'rejected_count': rejected_count,
        'decided_count': decided_count,
        'approval_rate': approval_rate,
        'avg_processing_time': avg_processing_time,
        'avg_processing_hours': avg_hours,
    }


@login_required
def dashboard(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    role = profile.role

    claims_qs = Claim.objects.all().select_related('patient', 'policy', 'hospital')

    if role == 'patient':
        claims_qs = claims_qs.filter(patient=request.user)
        policies = Policy.objects.filter(patient=request.user)
    elif role == 'hospital':
        claims_qs = claims_qs.filter(Q(hospital=request.user) | Q(hospital__isnull=True))
        policies = Policy.objects.none()
    else:  # insurer
        policies = Policy.objects.all()

    # Filter by query param
    status_filter = request.GET.get('status')
    if status_filter:
        claims_qs = claims_qs.filter(status=status_filter)

    search_query = request.GET.get('q', '').strip()
    if search_query:
        claims_qs = claims_qs.filter(
            Q(claim_number__icontains=search_query) |
            Q(patient__first_name__icontains=search_query) |
            Q(patient__last_name__icontains=search_query) |
            Q(diagnosis__icontains=search_query) |
            Q(policy__policy_number__icontains=search_query)
        )

    # Compute operational analytics metrics
    analytics = calculate_claim_analytics(claims_qs)

    context = {
        'profile': profile,
        'claims': claims_qs[:50],
        'policies': policies[:20] if role != 'hospital' else [],
        'total_claims': analytics['total_claims'],
        'pending_count': analytics['pending_count'],
        'approved_count': analytics['approved_count'],
        'settled_count': analytics['settled_count'],
        'rejected_count': analytics['rejected_count'],
        'decided_count': analytics['decided_count'],
        'approval_rate': analytics['approval_rate'],
        'avg_processing_time': analytics['avg_processing_time'],
        'status_filter': status_filter or '',
        'search_query': search_query,
    }
    return render(request, 'claims/dashboard.html', context)


@login_required
def claim_detail(request, pk):
    claim = get_object_or_404(Claim.objects.select_related('patient', 'policy', 'hospital'), pk=pk)
    user_role = request.user.profile.role

    # Security check: patients can only view their own claims
    if user_role == 'patient' and claim.patient != request.user:
        return HttpResponseForbidden("You do not have permission to view this claim.")

    doc_form = ClaimDocumentForm()
    history = claim.history.all().order_by('-changed_at')
    documents = claim.documents.all().order_by('-uploaded_at')

    return render(request, 'claims/claim_detail.html', {
        'claim': claim,
        'history': history,
        'documents': documents,
        'doc_form': doc_form,
        'user_role': user_role,
        'next_statuses': claim.next_possible_statuses if user_role == 'insurer' else [],
    })


@login_required
def claim_create(request):
    profile = request.user.profile
    if profile.role == 'insurer':
        messages.error(request, "Insurers cannot submit claims. Switch to a Patient or Hospital account.")
        return redirect('dashboard')

    if request.method == 'POST':
        form = ClaimForm(request.POST, user=request.user)
        if form.is_valid():
            claim = form.save(commit=False)
            if profile.role == 'patient':
                claim.patient = request.user
            elif profile.role == 'hospital':
                claim.hospital = request.user
                claim.patient = claim.policy.patient
            claim.status = Claim.STATUS_SUBMITTED
            claim.save()

            # Record initial history
            ClaimStatusHistory.objects.create(
                claim=claim,
                status=Claim.STATUS_SUBMITTED,
                remarks="Claim submitted for review.",
                changed_by=request.user
            )

            # Handle optional document upload in initial submit
            file = request.FILES.get('document')
            doc_type = request.POST.get('doc_type', 'bill')
            if file:
                ClaimDocument.objects.create(
                    claim=claim,
                    doc_type=doc_type,
                    file=file,
                    file_name=file.name,
                    uploaded_by=request.user
                )

            messages.success(request, f"Claim {claim.claim_number} filed successfully!")
            return redirect('claim_detail', pk=claim.pk)
    else:
        form = ClaimForm(user=request.user)

    return render(request, 'claims/claim_form.html', {'form': form, 'profile': profile})


@login_required
def claim_status_update(request, pk):
    claim = get_object_or_404(Claim, pk=pk)
    if request.user.profile.role != 'insurer':
        return HttpResponseForbidden("Only Insurers can change claim review status.")

    if request.method == 'POST':
        new_status = request.POST.get('status')
        remarks = request.POST.get('remarks', '').strip()
        approved_amount_val = request.POST.get('approved_amount', '').strip()

        if new_status not in claim.next_possible_statuses:
            messages.error(request, f"Invalid state transition from {claim.status} to {new_status}.")
            return redirect('claim_detail', pk=claim.pk)

        if new_status in ['Info Requested', 'Rejected'] and not remarks:
            messages.error(request, f"Remarks are required when changing status to {new_status}.")
            return redirect('claim_detail', pk=claim.pk)

        claim.status = new_status
        if remarks:
            claim.insurer_remarks = remarks

        if new_status == 'Approved':
            if approved_amount_val:
                try:
                    app_amt = Decimal(approved_amount_val)
                    if app_amt > claim.claim_amount:
                        messages.error(request, "Approved amount cannot exceed the claimed amount.")
                        return redirect('claim_detail', pk=claim.pk)
                    claim.approved_amount = app_amt
                except Exception:
                    messages.error(request, "Invalid approved amount format.")
                    return redirect('claim_detail', pk=claim.pk)
            else:
                claim.approved_amount = claim.claim_amount

        elif new_status == 'Settled':
            # Deduct from policy coverage
            payout = claim.approved_amount or claim.claim_amount
            claim.policy.claimed_amount += payout
            claim.policy.save()

        claim.save()

        ClaimStatusHistory.objects.create(
            claim=claim,
            status=new_status,
            remarks=remarks or f"Status changed to {new_status}",
            changed_by=request.user
        )

        messages.success(request, f"Claim status updated to '{new_status}'.")
    return redirect('claim_detail', pk=claim.pk)


@login_required
def claim_respond(request, pk):
    claim = get_object_or_404(Claim, pk=pk)
    if request.method == 'POST':
        response_text = request.POST.get('response', '').strip()
        if not response_text:
            messages.error(request, "Response message cannot be empty.")
            return redirect('claim_detail', pk=claim.pk)

        # Move status back to Under Review if requested
        claim.status = Claim.STATUS_UNDER_REVIEW
        claim.save()

        ClaimStatusHistory.objects.create(
            claim=claim,
            status=Claim.STATUS_UNDER_REVIEW,
            remarks=f"Patient/Hospital response: {response_text}",
            changed_by=request.user
        )
        messages.success(request, "Your response has been sent to the insurer.")
    return redirect('claim_detail', pk=claim.pk)


@login_required
def claim_document_upload(request, pk):
    claim = get_object_or_404(Claim, pk=pk)
    if request.method == 'POST':
        form = ClaimDocumentForm(request.POST, request.FILES)
        if form.is_valid():
            doc = form.save(commit=False)
            doc.claim = claim
            doc.uploaded_by = request.user
            doc.file_name = form.cleaned_data['file'].name
            doc.save()
            messages.success(request, f"Document '{doc.file_name}' uploaded successfully.")
        else:
            messages.error(request, "Failed to upload document. Please choose a valid file.")
    return redirect('claim_detail', pk=claim.pk)


@login_required
def policy_list(request):
    profile = request.user.profile
    if profile.role == 'patient':
        policies = Policy.objects.filter(patient=request.user)
    else:
        policies = Policy.objects.all().select_related('patient')
    return render(request, 'claims/policy_list.html', {'policies': policies, 'profile': profile})


@login_required
def policy_create(request):
    if request.user.profile.role != 'insurer':
        return HttpResponseForbidden("Only Insurers can issue new insurance policies.")

    if request.method == 'POST':
        form = PolicyForm(request.POST)
        if form.is_valid():
            policy = form.save(commit=False)
            policy.patient = form.cleaned_data['patient']
            policy.save()
            messages.success(request, f"Policy {policy.policy_number} issued for {policy.patient.get_full_name() or policy.patient.username}.")
            return redirect('policy_list')
    else:
        form = PolicyForm()

    return render(request, 'claims/policy_form.html', {'form': form})


def seed_demo_data(request):
    """Generates standard realistic test data for instant testing."""
    # 1. Create Insurer
    insurer_user, _ = User.objects.get_or_create(username='insurer_demo', defaults={'email': 'insurer@demo.com', 'first_name': 'Sarah', 'last_name': 'Jenkins'})
    insurer_user.set_password('demo1234')
    insurer_user.save()
    UserProfile.objects.update_or_create(user=insurer_user, defaults={'role': 'insurer', 'organization_name': 'Apex Shield Health Insurance'})

    # 2. Create Hospital
    hosp_user, _ = User.objects.get_or_create(username='hospital_demo', defaults={'email': 'metro@hospital.org', 'first_name': 'Dr. Robert', 'last_name': 'Chen'})
    hosp_user.set_password('demo1234')
    hosp_user.save()
    UserProfile.objects.update_or_create(user=hosp_user, defaults={'role': 'hospital', 'organization_name': 'Metro City General Hospital', 'address': '101 Healthcare Blvd, Suite 400'})

    # 3. Create Patient
    patient_user, _ = User.objects.get_or_create(username='patient_demo', defaults={'email': 'john.doe@example.com', 'first_name': 'John', 'last_name': 'Doe'})
    patient_user.set_password('demo1234')
    patient_user.save()
    UserProfile.objects.update_or_create(user=patient_user, defaults={'role': 'patient', 'phone': '+1 (555) 019-2834', 'address': '742 Evergreen Terrace'})

    # 4. Create Policies for Patient
    today = timezone.now().date()
    p1, _ = Policy.objects.get_or_create(
        policy_number='POL-GOLD-9840',
        defaults={
            'patient': patient_user,
            'coverage_amount': Decimal('50000.00'),
            'claimed_amount': Decimal('4200.00'),
            'start_date': today - dt.timedelta(days=120),
            'end_date': today + dt.timedelta(days=245),
            'status': 'active'
        }
    )

    p2, _ = Policy.objects.get_or_create(
        policy_number='POL-FAMILY-5521',
        defaults={
            'patient': patient_user,
            'coverage_amount': Decimal('100000.00'),
            'claimed_amount': Decimal('0.00'),
            'start_date': today - dt.timedelta(days=30),
            'end_date': today + dt.timedelta(days=335),
            'status': 'active'
        }
    )

    # 5. Create Sample Claims
    c1, _ = Claim.objects.get_or_create(
        claim_number='CLM-DEMO-001',
        defaults={
            'policy': p1,
            'patient': patient_user,
            'hospital': hosp_user,
            'diagnosis': 'Laparoscopic Appendectomy & Post-op Recovery',
            'treatment_details': 'Patient was admitted for acute abdominal pain. Successful laparoscopic appendectomy performed with 3-day inpatient stay.',
            'admission_date': today - dt.timedelta(days=45),
            'discharge_date': today - dt.timedelta(days=42),
            'claim_amount': Decimal('4200.00'),
            'approved_amount': Decimal('4200.00'),
            'status': Claim.STATUS_SETTLED,
            'insurer_remarks': 'All verified medical invoices approved. Payment settled directly to facility.',
        }
    )

    c2, _ = Claim.objects.get_or_create(
        claim_number='CLM-DEMO-002',
        defaults={
            'policy': p1,
            'patient': patient_user,
            'hospital': hosp_user,
            'diagnosis': 'Cardiology Diagnostics & Angiogram Consultation',
            'treatment_details': 'Cardiac stress test, echo scans, and outpatient consultation.',
            'admission_date': today - dt.timedelta(days=10),
            'discharge_date': today - dt.timedelta(days=10),
            'claim_amount': Decimal('1850.00'),
            'status': Claim.STATUS_UNDER_REVIEW,
            'insurer_remarks': 'Reviewing medical necessity documentation.',
        }
    )

    c3, _ = Claim.objects.get_or_create(
        claim_number='CLM-DEMO-003',
        defaults={
            'policy': p2,
            'patient': patient_user,
            'hospital': hosp_user,
            'diagnosis': 'Orthopedic Arthroscopy - Left Knee Meniscus Repair',
            'treatment_details': 'Knee MRI indicated lateral meniscus tear. Arthroscopic surgical repair executed.',
            'admission_date': today - dt.timedelta(days=3),
            'discharge_date': today - dt.timedelta(days=1),
            'claim_amount': Decimal('6500.00'),
            'status': Claim.STATUS_SUBMITTED,
        }
    )

    messages.success(request, "Demo accounts and sample data initialized successfully! Use patient_demo, hospital_demo, or insurer_demo (password: demo1234).")
    return redirect('login')


# ==============================================================================
# REST / JSON API FOR TKINTER & EXTERNAL CLIENTS
# ==============================================================================

@csrf_exempt
def api_login(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        data = request.POST

    username = data.get('username') or data.get('email')
    password = data.get('password')

    if '@' in str(username):
        try:
            u = User.objects.get(email__iexact=username)
            username = u.username
        except Exception:
            pass

    user = authenticate(username=username, password=password)
    if not user:
        return JsonResponse({'success': False, 'error': 'Invalid credentials'}, status=401)

    profile, _ = UserProfile.objects.get_or_create(user=user)
    return JsonResponse({
        'success': True,
        'user': {
            'id': user.id,
            'username': user.username,
            'full_name': user.get_full_name() or user.username,
            'email': user.email,
            'role': profile.role,
            'organization': profile.organization_name,
        }
    })


@csrf_exempt
def api_claims_list(request):
    if request.method == 'GET':
        role = request.GET.get('role')
        user_id = request.GET.get('user_id')
        status = request.GET.get('status')

        qs = Claim.objects.all().select_related('patient', 'policy', 'hospital')
        if role == 'patient' and user_id:
            qs = qs.filter(patient_id=user_id)
        if status:
            qs = qs.filter(status=status)

        claims = []
        for c in qs:
            claims.append({
                'id': c.id,
                'claim_number': c.claim_number,
                'policy_number': c.policy.policy_number,
                'patient_name': c.patient.get_full_name() or c.patient.username,
                'hospital_name': c.hospital.profile.display_name if c.hospital and hasattr(c.hospital, 'profile') else 'None',
                'diagnosis': c.diagnosis,
                'claim_amount': float(c.claim_amount),
                'approved_amount': float(c.approved_amount) if c.approved_amount else None,
                'status': c.status,
                'admission_date': str(c.admission_date),
                'discharge_date': str(c.discharge_date),
                'created_at': c.created_at.strftime('%Y-%m-%d %H:%M'),
                'insurer_remarks': c.insurer_remarks or '',
            })
        return JsonResponse({'claims': claims})

    elif request.method == 'POST':
        try:
            data = json.loads(request.body.decode('utf-8'))
        except Exception:
            data = request.POST

        policy_number = data.get('policy_number')
        try:
            policy = Policy.objects.get(policy_number=policy_number)
        except Policy.DoesNotExist:
            return JsonResponse({'error': f'Policy {policy_number} not found'}, status=400)

        claim_amt = Decimal(str(data.get('claim_amount', 0)))
        if claim_amt <= 0 or claim_amt > policy.remaining_amount:
            return JsonResponse({'error': 'Invalid claim amount or exceeds remaining coverage'}, status=400)

        claim = Claim.objects.create(
            policy=policy,
            patient=policy.patient,
            diagnosis=data.get('diagnosis', 'Not specified'),
            treatment_details=data.get('treatment_details', ''),
            admission_date=data.get('admission_date'),
            discharge_date=data.get('discharge_date'),
            claim_amount=claim_amt,
            status=Claim.STATUS_SUBMITTED
        )

        ClaimStatusHistory.objects.create(
            claim=claim,
            status=Claim.STATUS_SUBMITTED,
            remarks="Submitted via API / Tkinter Desktop Client"
        )

        return JsonResponse({'success': True, 'claim_id': claim.id, 'claim_number': claim.claim_number})

    return JsonResponse({'error': 'Method not allowed'}, status=405)


@csrf_exempt
def api_claim_detail(request, pk):
    try:
        c = Claim.objects.select_related('patient', 'policy', 'hospital').get(pk=pk)
    except Claim.DoesNotExist:
        return JsonResponse({'error': 'Claim not found'}, status=404)

    docs = [{'id': d.id, 'type': d.get_doc_type_display(), 'name': d.file_name, 'url': d.file.url if d.file else ''} for d in c.documents.all()]
    hist = [{'status': h.status, 'remarks': h.remarks, 'changed_at': h.changed_at.strftime('%Y-%m-%d %H:%M'), 'by': h.changed_by.username if h.changed_by else 'System'} for h in c.history.all()]

    return JsonResponse({
        'id': c.id,
        'claim_number': c.claim_number,
        'policy_number': c.policy.policy_number,
        'policy_coverage': float(c.policy.coverage_amount),
        'policy_remaining': float(c.policy.remaining_amount),
        'patient_name': c.patient.get_full_name() or c.patient.username,
        'patient_email': c.patient.email,
        'hospital_name': c.hospital.profile.display_name if c.hospital and hasattr(c.hospital, 'profile') else 'None',
        'diagnosis': c.diagnosis,
        'treatment_details': c.treatment_details,
        'admission_date': str(c.admission_date),
        'discharge_date': str(c.discharge_date),
        'claim_amount': float(c.claim_amount),
        'approved_amount': float(c.approved_amount) if c.approved_amount else None,
        'status': c.status,
        'next_possible_statuses': c.next_possible_statuses,
        'insurer_remarks': c.insurer_remarks or '',
        'created_at': c.created_at.strftime('%Y-%m-%d %H:%M'),
        'documents': docs,
        'history': hist
    })


@csrf_exempt
def api_claim_status_update(request, pk):
    try:
        claim = Claim.objects.get(pk=pk)
    except Claim.DoesNotExist:
        return JsonResponse({'error': 'Claim not found'}, status=404)

    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        data = request.POST

    new_status = data.get('status')
    remarks = data.get('remarks', '').strip()
    approved_amount = data.get('approved_amount')

    if new_status not in claim.next_possible_statuses:
        return JsonResponse({'error': f"Invalid transition from {claim.status} to {new_status}"}, status=400)

    claim.status = new_status
    if remarks:
        claim.insurer_remarks = remarks
    if approved_amount is not None and str(approved_amount).strip():
        claim.approved_amount = Decimal(str(approved_amount))
    elif new_status == 'Approved' and not claim.approved_amount:
        claim.approved_amount = claim.claim_amount

    if new_status == 'Settled':
        payout = claim.approved_amount or claim.claim_amount
        claim.policy.claimed_amount += payout
        claim.policy.save()

    claim.save()

    ClaimStatusHistory.objects.create(
        claim=claim,
        status=new_status,
        remarks=remarks or f"Updated via Tkinter API to {new_status}"
    )

    return JsonResponse({'success': True, 'status': claim.status, 'approved_amount': float(claim.approved_amount or 0)})


@csrf_exempt
def api_policies_list(request):
    qs = Policy.objects.all().select_related('patient')
    policies = []
    for p in qs:
        policies.append({
            'id': p.id,
            'policy_number': p.policy_number,
            'patient_name': p.patient.get_full_name() or p.patient.username,
            'patient_email': p.patient.email,
            'coverage_amount': float(p.coverage_amount),
            'claimed_amount': float(p.claimed_amount),
            'remaining_amount': float(p.remaining_amount),
            'start_date': str(p.start_date),
            'end_date': str(p.end_date),
            'status': p.status,
        })
    return JsonResponse({'policies': policies})


def api_dashboard_stats(request):
    analytics = calculate_claim_analytics(Claim.objects.all())
    return JsonResponse({
        'total_claims': analytics['total_claims'],
        'pending_claims': analytics['pending_count'],
        'approved_claims': analytics['approved_count'],
        'settled_claims': analytics['settled_count'],
        'rejected_claims': analytics['rejected_count'],
        'decided_claims': analytics['decided_count'],
        'approval_rate': analytics['approval_rate'],
        'avg_processing_time': analytics['avg_processing_time'],
        'avg_processing_hours': analytics['avg_processing_hours'],
        'total_policies': Policy.objects.count(),
        'total_settled_payout': float(Claim.objects.filter(status='Settled').aggregate(total=Sum('approved_amount'))['total'] or 0),
    })
