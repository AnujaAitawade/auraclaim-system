"""
AuraClaim Master Launcher
Start the Django Web Portal, the Tkinter Desktop Application, or both!
"""

import sys
import os
import subprocess
import time
import webbrowser

def main():
    print("=" * 60)
    print("  AURACLAIM - HEALTH INSURANCE CLAIM SYSTEM")
    print("  Django Web Platform + Tkinter Desktop Application")
    print("=" * 60)
    print("1. Start Django Web Server (http://127.0.0.1:8000)")
    print("2. Launch Tkinter Desktop Client")
    print("3. Launch BOTH (Start Web Server + Open Tkinter App)")
    print("4. Seed / Reset Demo Accounts & Sample Claims")
    print("5. Run Django Unit & System Tests")
    print("0. Exit")
    print("-" * 60)

    choice = input("Select an option (1-5) [default: 3]: ").strip() or "3"

    python_bin = sys.executable

    if choice == "1":
        print("\nStarting Django Web Server on http://127.0.0.1:8000 ...")
        subprocess.run([python_bin, "manage.py", "runserver"])

    elif choice == "2":
        print("\nLaunching Tkinter Desktop Client...")
        subprocess.run([python_bin, "tkinter_client.py"])

    elif choice == "3":
        print("\n[1/2] Starting Django Web Server in background...")
        server_proc = subprocess.Popen([python_bin, "manage.py", "runserver"])
        time.sleep(2)
        print("[2/2] Launching Tkinter Desktop Application...")
        try:
            subprocess.run([python_bin, "tkinter_client.py"])
        finally:
            print("\nShutting down Django web server...")
            server_proc.terminate()

    elif choice == "4":
        print("\nSeeding demo data into SQLite database...")
        subprocess.run([python_bin, "manage.py", "shell", "-c", 
                        "from claims.views import seed_demo_data; from django.test import RequestFactory; from django.contrib.messages.storage.fallback import FallbackStorage; req = RequestFactory().get('/seed-demo/'); req.session={}; req._messages=FallbackStorage(req); seed_demo_data(req); print('Demo accounts initialized!')"])
        print("\nAccounts ready:")
        print(" - Insurer: insurer_demo / demo1234")
        print(" - Hospital: hospital_demo / demo1234")
        print(" - Patient: patient_demo / demo1234")
        print(" - Admin: admin / admin1234")

    elif choice == "5":
        print("\nRunning Django system tests...")
        subprocess.run([python_bin, "manage.py", "test"])

if __name__ == "__main__":
    main()
