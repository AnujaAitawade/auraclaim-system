"""
AuraClaim - Desktop Client (Tkinter GUI)
Compatible with Python 3.8+ using standard library (tkinter, urllib, json).
Connects to the Django Health Insurance Claim System web server / API.
"""

import sys
import os
import json
import urllib.request
import urllib.parse
import urllib.error
import webbrowser
from decimal import Decimal
import tkinter as tk
from tkinter import ttk, messagebox

# Default Django API endpoint
API_BASE_URL = os.environ.get("AURACLAIM_API_URL", "http://127.0.0.1:8000")


class ApiClient:
    """Helper client to talk to the Django REST/JSON backend."""

    def __init__(self, base_url=API_BASE_URL):
        self.base_url = base_url.rstrip("/")
        self.user = None

    def post_json(self, endpoint, data):
        url = f"{self.base_url}{endpoint}"
        payload = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=payload,
            headers={"Content-Type": "application/json", "User-Agent": "AuraClaim-Tkinter/1.0"}
        )
        try:
            with urllib.request.urlopen(req, timeout=8) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                err_data = json.loads(e.read().decode("utf-8"))
                return {"error": err_data.get("error") or err_data.get("detail") or str(e)}
            except Exception:
                return {"error": f"HTTP {e.code}: {e.reason}"}
        except Exception as e:
            return {"error": f"Connection failed: {str(e)}"}

    def get_json(self, endpoint, params=None):
        url = f"{self.base_url}{endpoint}"
        if params:
            qs = urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})
            url = f"{url}?{qs}" if qs else url
        req = urllib.request.Request(
            url,
            headers={"Accept": "application/json", "User-Agent": "AuraClaim-Tkinter/1.0"}
        )
        try:
            with urllib.request.urlopen(req, timeout=8) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                err_data = json.loads(e.read().decode("utf-8"))
                return {"error": err_data.get("error") or err_data.get("detail") or str(e)}
            except Exception:
                return {"error": f"HTTP {e.code}: {e.reason}"}
        except Exception as e:
            return {"error": f"Connection failed: {str(e)}"}


class AuraClaimApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AuraClaim - Health Insurance Desktop Client")
        self.geometry("1100x720")
        self.minsize(950, 600)

        # Style setup
        self.api = ApiClient()
        self.current_user = None
        self.claims_cache = []

        self._configure_styles()
        self.show_login_frame()

    def _configure_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        # Color palette
        self.c_bg = "#f8fafc"
        self.c_brand = "#0b5cab"
        self.c_brand_dark = "#094b8c"
        self.c_card = "#ffffff"
        self.c_border = "#e2e8f0"
        self.c_text = "#1e293b"
        self.c_muted = "#64748b"

        self.configure(bg=self.c_bg)

        style.configure("TFrame", background=self.c_bg)
        style.configure("Card.TFrame", background=self.c_card, relief="flat")
        style.configure("TLabel", background=self.c_bg, foreground=self.c_text, font=("Segoe UI", 9))
        style.configure("Card.TLabel", background=self.c_card, foreground=self.c_text, font=("Segoe UI", 9))
        style.configure("Header.TLabel", background=self.c_brand, foreground="#ffffff", font=("Segoe UI", 12, "bold"))
        style.configure("SubHeader.TLabel", background=self.c_card, foreground=self.c_text, font=("Segoe UI", 10, "bold"))
        style.configure("Brand.TButton", font=("Segoe UI", 9, "bold"), background=self.c_brand, foreground="#ffffff")
        style.map("Brand.TButton", background=[("active", self.c_brand_dark)])

        # Treeview
        style.configure("Treeview",
                        background="#ffffff",
                        foreground=self.c_text,
                        rowheight=28,
                        fieldbackground="#ffffff",
                        font=("Segoe UI", 9))
        style.configure("Treeview.Heading",
                        font=("Segoe UI", 9, "bold"),
                        background="#f1f5f9",
                        foreground="#334155")
        style.map("Treeview", background=[("selected", "#dbeafe")], foreground=[("selected", "#1e3a8a")])

    def clear_root(self):
        for widget in self.winfo_children():
            widget.destroy()

    # =========================================================================
    # LOGIN SCREEN
    # =========================================================================
    def show_login_frame(self):
        self.clear_root()

        container = tk.Frame(self, bg=self.c_bg)
        container.place(relx=0.5, rely=0.5, anchor="center")

        card = tk.Frame(container, bg=self.c_card, bd=1, relief="solid", highlightthickness=0)
        card.configure(highlightbackground=self.c_border)
        card.pack(padx=20, pady=20, ipadx=24, ipady=24)

        # Header
        top_band = tk.Frame(card, bg=self.c_brand)
        top_band.pack(fill="x", pady=(0, 20), ipady=14)

        title_lbl = tk.Label(top_band, text="AuraClaim Desktop", font=("Segoe UI", 16, "bold"), bg=self.c_brand, fg="#ffffff")
        title_lbl.pack()
        subtitle_lbl = tk.Label(top_band, text="Health Insurance Claim System • Desktop Portal", font=("Segoe UI", 9), bg=self.c_brand, fg="#bae6fd")
        subtitle_lbl.pack()

        # Server URL row
        url_frame = tk.Frame(card, bg=self.c_card)
        url_frame.pack(fill="x", pady=(0, 10))
        tk.Label(url_frame, text="Server Endpoint:", font=("Segoe UI", 8, "bold"), bg=self.c_card, fg=self.c_muted).pack(anchor="w")
        self.server_entry = ttk.Entry(url_frame, width=38)
        self.server_entry.insert(0, self.api.base_url)
        self.server_entry.pack(fill="x", pady=2)

        # Username
        u_frame = tk.Frame(card, bg=self.c_card)
        u_frame.pack(fill="x", pady=6)
        tk.Label(u_frame, text="Username or Email:", font=("Segoe UI", 9, "bold"), bg=self.c_card, fg=self.c_text).pack(anchor="w")
        self.username_entry = ttk.Entry(u_frame, width=38)
        self.username_entry.pack(fill="x", pady=2)
        self.username_entry.focus()

        # Password
        p_frame = tk.Frame(card, bg=self.c_card)
        p_frame.pack(fill="x", pady=6)
        tk.Label(p_frame, text="Password:", font=("Segoe UI", 9, "bold"), bg=self.c_card, fg=self.c_text).pack(anchor="w")
        self.password_entry = ttk.Entry(p_frame, show="•", width=38)
        self.password_entry.pack(fill="x", pady=2)
        self.password_entry.bind("<Return>", lambda e: self.do_login())

        # Submit button
        login_btn = tk.Button(card, text="Sign In to AuraClaim", bg=self.c_brand, fg="#ffffff",
                              font=("Segoe UI", 10, "bold"), bd=0, relief="flat", cursor="hand2",
                              activebackground=self.c_brand_dark, activeforeground="#ffffff",
                              command=self.do_login)
        login_btn.pack(fill="x", pady=(14, 10), ipady=6)

        # Quick Demo Buttons
        demo_box = tk.LabelFrame(card, text="Quick Demo Logins", bg=self.c_card, fg=self.c_muted, font=("Segoe UI", 8, "bold"), padx=10, pady=8)
        demo_box.pack(fill="x", pady=(6, 4))

        btn_row = tk.Frame(demo_box, bg=self.c_card)
        btn_row.pack(fill="x")

        def autofill(u, p):
            self.username_entry.delete(0, tk.END)
            self.username_entry.insert(0, u)
            self.password_entry.delete(0, tk.END)
            self.password_entry.insert(0, p)
            self.do_login()

        tk.Button(btn_row, text="Insurer Demo", bg="#ede9fe", fg="#5b21b6", font=("Segoe UI", 8, "bold"),
                  bd=0, cursor="hand2", padx=6, pady=4, command=lambda: autofill("insurer_demo", "demo1234")).pack(side="left", expand=True, fill="x", padx=2)
        tk.Button(btn_row, text="Hospital Demo", bg="#dcfce7", fg="#166534", font=("Segoe UI", 8, "bold"),
                  bd=0, cursor="hand2", padx=6, pady=4, command=lambda: autofill("hospital_demo", "demo1234")).pack(side="left", expand=True, fill="x", padx=2)
        tk.Button(btn_row, text="Patient Demo", bg="#e0f2fe", fg="#075985", font=("Segoe UI", 8, "bold"),
                  bd=0, cursor="hand2", padx=6, pady=4, command=lambda: autofill("patient_demo", "demo1234")).pack(side="left", expand=True, fill="x", padx=2)

        # Browser link
        link_btn = tk.Button(card, text="Open Web Portal in Browser ↗", bg=self.c_card, fg=self.c_brand,
                             font=("Segoe UI", 8, "underline"), bd=0, cursor="hand2",
                             command=lambda: webbrowser.open(self.api.base_url))
        link_btn.pack(pady=(8, 0))

    def do_login(self):
        server = self.server_entry.get().strip().rstrip("/")
        username = self.username_entry.get().strip()
        password = self.password_entry.get()

        if not username or not password:
            messagebox.showwarning("Incomplete Fields", "Please enter both username and password.")
            return

        self.api.base_url = server
        res = self.api.post_json("/api/auth/login/", {"username": username, "password": password})

        if res.get("success"):
            self.current_user = res.get("user")
            self.show_main_app()
        else:
            err = res.get("error", "Invalid credentials or server unreachable.")
            messagebox.showerror("Authentication Failed", f"{err}\n\nEnsure Django server is running:\npython manage.py runserver")

    # =========================================================================
    # MAIN APPLICATION DASHBOARD
    # =========================================================================
    def show_main_app(self):
        self.clear_root()

        # Top Header Bar
        header = tk.Frame(self, bg=self.c_brand, height=54)
        header.pack(fill="x")

        # Left Title
        left_h = tk.Frame(header, bg=self.c_brand)
        left_h.pack(side="left", padx=16, pady=10)
        tk.Label(left_h, text="AuraClaim", font=("Segoe UI", 13, "bold"), bg=self.c_brand, fg="#ffffff").pack(side="left")
        tk.Label(left_h, text=" | Desktop Adjudication Client", font=("Segoe UI", 10), bg=self.c_brand, fg="#bae6fd").pack(side="left")

        # Right User Info
        right_h = tk.Frame(header, bg=self.c_brand)
        right_h.pack(side="right", padx=16, pady=10)

        user_name = self.current_user.get("full_name") or self.current_user.get("username")
        role = (self.current_user.get("role") or "user").upper()

        tk.Label(right_h, text=f"{user_name} ({role})", font=("Segoe UI", 9, "bold"), bg=self.c_brand, fg="#ffffff").pack(side="left", padx=8)

        web_btn = tk.Button(right_h, text="Web View ↗", font=("Segoe UI", 8, "bold"), bg="#0284c7", fg="#ffffff",
                            bd=0, padx=8, pady=2, cursor="hand2", command=lambda: webbrowser.open(f"{self.api.base_url}/dashboard/"))
        web_btn.pack(side="left", padx=4)

        logout_btn = tk.Button(right_h, text="Logout", font=("Segoe UI", 8, "bold"), bg="#b91c1c", fg="#ffffff",
                               bd=0, padx=8, pady=2, cursor="hand2", command=self.show_login_frame)
        logout_btn.pack(side="left", padx=4)

        # KPI Summary Ribbon
        self.ribbon = tk.Frame(self, bg="#ffffff", bd=1, relief="solid")
        self.ribbon.configure(highlightbackground=self.c_border)
        self.ribbon.pack(fill="x", padx=16, pady=(12, 6), ipady=6)

        self.kpi_labels = {}
        for key, title, color in [
            ("total", "Total Claims", "#0f172a"),
            ("pending", "In Review", "#b45309"),
            ("approved", "Approved", "#15803d"),
            ("settled", "Settled", "#6d28d9"),
            ("approval_rate", "Approval Rate", "#0284c7"),
            ("avg_time", "Avg Turnaround", "#059669"),
        ]:
            col = tk.Frame(self.ribbon, bg="#ffffff")
            col.pack(side="left", expand=True, fill="both", padx=8)
            tk.Label(col, text=title.upper(), font=("Segoe UI", 7, "bold"), bg="#ffffff", fg=self.c_muted).pack(anchor="w")
            lbl = tk.Label(col, text="—", font=("Segoe UI", 13, "bold"), bg="#ffffff", fg=color)
            lbl.pack(anchor="w")
            self.kpi_labels[key] = lbl

        # Action Toolbar (Search, Filter, New Claim, Refresh)
        toolbar = tk.Frame(self, bg=self.c_bg)
        toolbar.pack(fill="x", padx=16, pady=6)

        tk.Label(toolbar, text="Search:", font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 4))
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(toolbar, textvariable=self.search_var, width=22)
        self.search_entry.pack(side="left", padx=(0, 10))
        self.search_var.trace_add("write", lambda *args: self.filter_claims_table())

        tk.Label(toolbar, text="Status Filter:", font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 4))
        self.status_filter_var = tk.StringVar(value="All")
        status_cb = ttk.Combobox(toolbar, textvariable=self.status_filter_var, state="readonly", width=14,
                                 values=["All", "Submitted", "Under Review", "Info Requested", "Approved", "Settled", "Rejected"])
        status_cb.pack(side="left", padx=(0, 12))
        status_cb.bind("<<ComboboxSelected>>", lambda e: self.filter_claims_table())

        refresh_btn = tk.Button(toolbar, text="⟳ Refresh", font=("Segoe UI", 9), bg="#e2e8f0", fg=self.c_text,
                                bd=0, padx=10, pady=3, cursor="hand2", command=self.load_claims)
        refresh_btn.pack(side="left", padx=4)

        if self.current_user.get("role") != "insurer":
            new_btn = tk.Button(toolbar, text="+ Submit New Claim", font=("Segoe UI", 9, "bold"), bg=self.c_brand, fg="#ffffff",
                                bd=0, padx=12, pady=3, cursor="hand2", command=self.open_new_claim_dialog)
            new_btn.pack(side="right")

        # Main Paned View: Left Table, Right Details Inspector
        paned = ttk.PanedWindow(self, orient="horizontal")
        paned.pack(fill="both", expand=True, padx=16, pady=(4, 12))

        # Left Panel (Claims Table)
        left_frame = tk.Frame(paned, bg="#ffffff", bd=1, relief="solid")
        left_frame.configure(highlightbackground=self.c_border)
        paned.add(left_frame, weight=3)

        cols = ("claim_number", "patient", "policy", "claim_amount", "approved_amount", "status", "created_at")
        self.tree = ttk.Treeview(left_frame, columns=cols, show="headings", selectmode="browse")

        self.tree.heading("claim_number", text="Claim #")
        self.tree.heading("patient", text="Patient")
        self.tree.heading("policy", text="Policy")
        self.tree.heading("claim_amount", text="Claimed ($)")
        self.tree.heading("approved_amount", text="Approved ($)")
        self.tree.heading("status", text="Status")
        self.tree.heading("created_at", text="Date")

        self.tree.column("claim_number", width=120, anchor="w")
        self.tree.column("patient", width=130, anchor="w")
        self.tree.column("policy", width=120, anchor="w")
        self.tree.column("claim_amount", width=90, anchor="e")
        self.tree.column("approved_amount", width=90, anchor="e")
        self.tree.column("status", width=110, anchor="center")
        self.tree.column("created_at", width=110, anchor="center")

        tree_scroll = ttk.Scrollbar(left_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=tree_scroll.set)

        self.tree.pack(side="left", fill="both", expand=True)
        tree_scroll.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_claim_selected)

        # Right Panel (Claim Inspector & Decision Actions)
        self.right_frame = tk.Frame(paned, bg="#ffffff", bd=1, relief="solid", padx=14, pady=12)
        self.right_frame.configure(highlightbackground=self.c_border)
        paned.add(self.right_frame, weight=2)

        self._build_inspector_panel()

        # Load initial data
        self.load_stats()
        self.load_claims()

    def _build_inspector_panel(self):
        for w in self.right_frame.winfo_children():
            w.destroy()

        self.inspector_title = tk.Label(self.right_frame, text="Select a claim to inspect", font=("Segoe UI", 11, "bold"), bg="#ffffff", fg=self.c_text)
        self.inspector_title.pack(anchor="w", pady=(0, 6))

        # Details text area
        self.details_text = tk.Text(self.right_frame, bg="#f8fafc", fg=self.c_text, font=("Consolas", 9),
                                    bd=1, relief="solid", highlightthickness=0, height=14, wrap="word")
        self.details_text.pack(fill="both", expand=True, pady=(0, 10))
        self.details_text.insert(tk.END, "Click any claim on the left table to inspect clinical diagnosis, financial allowance, documents, and adjudication history.")
        self.details_text.configure(state="disabled")

        # Insurer Decision Controls Container
        self.decision_box = tk.LabelFrame(self.right_frame, text="Adjudication Action (Insurer Only)", bg="#ffffff",
                                          font=("Segoe UI", 8, "bold"), fg=self.c_brand, padx=10, pady=8)
        self.decision_box.pack(fill="x")

        dec_row1 = tk.Frame(self.decision_box, bg="#ffffff")
        dec_row1.pack(fill="x", pady=2)
        tk.Label(dec_row1, text="Target Status:", font=("Segoe UI", 8, "bold"), bg="#ffffff").pack(side="left", padx=(0, 4))
        self.action_status_var = tk.StringVar()
        self.action_status_cb = ttk.Combobox(dec_row1, textvariable=self.action_status_var, state="readonly", width=16)
        self.action_status_cb.pack(side="left", padx=(0, 10))

        tk.Label(dec_row1, text="Appr ($):", font=("Segoe UI", 8, "bold"), bg="#ffffff").pack(side="left", padx=(0, 4))
        self.approved_amt_entry = ttk.Entry(dec_row1, width=10)
        self.approved_amt_entry.pack(side="left")

        dec_row2 = tk.Frame(self.decision_box, bg="#ffffff")
        dec_row2.pack(fill="x", pady=4)
        tk.Label(dec_row2, text="Remarks:", font=("Segoe UI", 8, "bold"), bg="#ffffff").pack(anchor="w")
        self.remarks_entry = ttk.Entry(dec_row2, width=40)
        self.remarks_entry.pack(fill="x", pady=2)

        action_btn_row = tk.Frame(self.decision_box, bg="#ffffff")
        action_btn_row.pack(fill="x", pady=(4, 0))

        self.apply_action_btn = tk.Button(action_btn_row, text="Execute Status Transition", bg=self.c_brand, fg="#ffffff",
                                          font=("Segoe UI", 8, "bold"), bd=0, padx=10, pady=4, cursor="hand2",
                                          command=self.submit_status_transition)
        self.apply_action_btn.pack(side="left")

        self.open_browser_btn = tk.Button(action_btn_row, text="Open in Browser ↗", bg="#e2e8f0", fg=self.c_text,
                                          font=("Segoe UI", 8), bd=0, padx=8, pady=4, cursor="hand2",
                                          command=self.open_selected_in_browser)
        self.open_browser_btn.pack(side="right")

    def load_stats(self):
        res = self.api.get_json("/api/stats/")
        if "error" not in res:
            self.kpi_labels["total"].configure(text=str(res.get("total_claims", 0)))
            self.kpi_labels["pending"].configure(text=str(res.get("pending_claims", 0)))
            self.kpi_labels["approved"].configure(text=str(res.get("approved_claims", 0)))
            self.kpi_labels["settled"].configure(text=str(res.get("settled_claims", 0)))
            rate = res.get("approval_rate", 0)
            self.kpi_labels["approval_rate"].configure(text=f"{rate}%")
            self.kpi_labels["avg_time"].configure(text=str(res.get("avg_processing_time", "—")))

    def load_claims(self):
        params = {}
        role = self.current_user.get("role")
        if role == "patient":
            params["role"] = "patient"
            params["user_id"] = self.current_user.get("id")

        res = self.api.get_json("/api/claims/", params)
        if "error" in res:
            messagebox.showerror("Error Fetching Claims", res.get("error"))
            return

        self.claims_cache = res.get("claims", [])
        self.filter_claims_table()

    def filter_claims_table(self):
        q = self.search_var.get().strip().lower()
        stat_filter = self.status_filter_var.get()

        for row in self.tree.get_children():
            self.tree.delete(row)

        for c in self.claims_cache:
            if stat_filter != "All" and c.get("status") != stat_filter:
                continue
            if q:
                c_num = c.get("claim_number", "").lower()
                pat = c.get("patient_name", "").lower()
                diag = c.get("diagnosis", "").lower()
                pol = c.get("policy_number", "").lower()
                if q not in c_num and q not in pat and q not in diag and q not in pol:
                    continue

            appr = f"${c.get('approved_amount'):,.2f}" if c.get("approved_amount") is not None else "—"
            self.tree.insert("", "end", iid=str(c.get("id")), values=(
                c.get("claim_number"),
                c.get("patient_name"),
                c.get("policy_number"),
                f"${c.get('claim_amount', 0):,.2f}",
                appr,
                c.get("status"),
                c.get("created_at")[:10] if c.get("created_at") else ""
            ))

    def on_claim_selected(self, event):
        selected = self.tree.selection()
        if not selected:
            return
        claim_id = selected[0]
        res = self.api.get_json(f"/api/claims/{claim_id}/")
        if "error" in res:
            return

        self.selected_claim_data = res
        self.inspector_title.configure(text=f"{res.get('claim_number')} [{res.get('status')}]")

        info_lines = [
            f"CLAIM:        {res.get('claim_number')}",
            f"STATUS:       {res.get('status')}",
            f"PATIENT:      {res.get('patient_name')} ({res.get('patient_email')})",
            f"HOSPITAL:     {res.get('hospital_name')}",
            f"POLICY:       {res.get('policy_number')} (Coverage: ${res.get('policy_coverage', 0):,.2f} | Remaining: ${res.get('policy_remaining', 0):,.2f})",
            f"ADMISSION:    {res.get('admission_date')} -> {res.get('discharge_date')}",
            f"CLAIMED AMT:  ${res.get('claim_amount', 0):,.2f}",
            f"APPROVED AMT: ${res.get('approved_amount', 0):,.2f}" if res.get('approved_amount') else "APPROVED AMT: None",
            "-" * 45,
            f"DIAGNOSIS:\n{res.get('diagnosis')}",
            "-" * 45,
            f"TREATMENT NOTES:\n{res.get('treatment_details') or 'None'}",
            "-" * 45,
            f"INSURER REMARKS:\n{res.get('insurer_remarks') or 'None'}",
        ]

        docs = res.get("documents", [])
        info_lines.append("-" * 45)
        info_lines.append(f"DOCUMENTS ({len(docs)}):")
        for d in docs:
            info_lines.append(f" • [{d.get('type')}] {d.get('name')}")

        hist = res.get("history", [])
        info_lines.append("-" * 45)
        info_lines.append("TIMELINE HISTORY:")
        for h in hist:
            info_lines.append(f" • {h.get('changed_at')} -> {h.get('status')}: {h.get('remarks') or ''}")

        self.details_text.configure(state="normal")
        self.details_text.delete("1.0", tk.END)
        self.details_text.insert(tk.END, "\n".join(info_lines))
        self.details_text.configure(state="disabled")

        # Update available decision transitions
        next_s = res.get("next_possible_statuses", [])
        is_insurer = self.current_user.get("role") == "insurer"

        if is_insurer and next_s:
            self.action_status_cb.configure(values=next_s, state="readonly")
            self.action_status_cb.current(0)
            self.approved_amt_entry.delete(0, tk.END)
            self.approved_amt_entry.insert(0, str(res.get("claim_amount", "")))
            self.apply_action_btn.configure(state="normal")
        else:
            self.action_status_cb.configure(values=[], state="disabled")
            self.apply_action_btn.configure(state="disabled")

    def submit_status_transition(self):
        if not hasattr(self, "selected_claim_data"):
            return
        cid = self.selected_claim_data.get("id")
        new_status = self.action_status_var.get()
        remarks = self.remarks_entry.get().strip()
        approved_amt = self.approved_amt_entry.get().strip()

        if not new_status:
            messagebox.showwarning("Notice", "Please select a target status.")
            return

        payload = {"status": new_status, "remarks": remarks}
        if approved_amt:
            payload["approved_amount"] = approved_amt

        res = self.api.post_json(f"/api/claims/{cid}/status/", payload)
        if res.get("success"):
            messagebox.showinfo("Success", f"Claim status updated to {new_status}!")
            self.remarks_entry.delete(0, tk.END)
            self.load_stats()
            self.load_claims()
            # re-select
            self.tree.selection_set(str(cid))
        else:
            messagebox.showerror("Update Error", res.get("error", "Unable to update claim status."))

    def open_selected_in_browser(self):
        if hasattr(self, "selected_claim_data"):
            cid = self.selected_claim_data.get("id")
            webbrowser.open(f"{self.api.base_url}/claims/{cid}/")

    # =========================================================================
    # NEW CLAIM MODAL
    # =========================================================================
    def open_new_claim_dialog(self):
        dialog = tk.Toplevel(self)
        dialog.title("Submit New Claim - AuraClaim")
        dialog.geometry("480x520")
        dialog.transient(self)
        dialog.grab_set()

        frame = tk.Frame(dialog, padx=20, pady=20, bg="#ffffff")
        frame.pack(fill="both", expand=True)

        tk.Label(frame, text="Submit Medical Claim", font=("Segoe UI", 12, "bold"), bg="#ffffff", fg=self.c_brand).pack(anchor="w", pady=(0, 10))

        # Policy Number
        tk.Label(frame, text="Policy Number (e.g. POL-GOLD-9840):", font=("Segoe UI", 8, "bold"), bg="#ffffff").pack(anchor="w")
        pol_entry = ttk.Entry(frame, width=35)
        pol_entry.pack(fill="x", pady=2)

        # Diagnosis
        tk.Label(frame, text="Diagnosis:", font=("Segoe UI", 8, "bold"), bg="#ffffff").pack(anchor="w", pady=(6, 0))
        diag_entry = ttk.Entry(frame, width=35)
        diag_entry.pack(fill="x", pady=2)

        # Dates
        d_frame = tk.Frame(frame, bg="#ffffff")
        d_frame.pack(fill="x", pady=6)
        tk.Label(d_frame, text="Admission (YYYY-MM-DD):", font=("Segoe UI", 8, "bold"), bg="#ffffff").pack(side="left")
        adm_entry = ttk.Entry(d_frame, width=14)
        adm_entry.pack(side="right")

        d_frame2 = tk.Frame(frame, bg="#ffffff")
        d_frame2.pack(fill="x", pady=6)
        tk.Label(d_frame2, text="Discharge (YYYY-MM-DD):", font=("Segoe UI", 8, "bold"), bg="#ffffff").pack(side="left")
        dis_entry = ttk.Entry(d_frame2, width=14)
        dis_entry.pack(side="right")

        # Claim Amount
        tk.Label(frame, text="Claim Amount ($ USD):", font=("Segoe UI", 8, "bold"), bg="#ffffff").pack(anchor="w", pady=(6, 0))
        amt_entry = ttk.Entry(frame, width=35)
        amt_entry.pack(fill="x", pady=2)

        # Treatment Notes
        tk.Label(frame, text="Treatment Details:", font=("Segoe UI", 8, "bold"), bg="#ffffff").pack(anchor="w", pady=(6, 0))
        treat_txt = tk.Text(frame, height=4, font=("Segoe UI", 9), bd=1, relief="solid")
        treat_txt.pack(fill="x", pady=2)

        def submit():
            pol = pol_entry.get().strip()
            diag = diag_entry.get().strip()
            adm = adm_entry.get().strip()
            dis = dis_entry.get().strip()
            amt = amt_entry.get().strip()
            treat = treat_txt.get("1.0", tk.END).strip()

            if not pol or not diag or not adm or not dis or not amt:
                messagebox.showwarning("Notice", "Please fill in all required fields.", parent=dialog)
                return

            payload = {
                "policy_number": pol,
                "diagnosis": diag,
                "admission_date": adm,
                "discharge_date": dis,
                "claim_amount": amt,
                "treatment_details": treat,
            }
            res = self.api.post_json("/api/claims/", payload)
            if res.get("success"):
                messagebox.showinfo("Claim Submitted", f"Claim {res.get('claim_number')} created successfully!", parent=dialog)
                dialog.destroy()
                self.load_stats()
                self.load_claims()
            else:
                messagebox.showerror("Error", res.get("error", "Failed to submit claim."), parent=dialog)

        tk.Button(frame, text="Submit Claim", bg=self.c_brand, fg="#ffffff", font=("Segoe UI", 9, "bold"),
                  bd=0, pady=6, cursor="hand2", command=submit).pack(fill="x", pady=(14, 0))


if __name__ == "__main__":
    app = AuraClaimApp()
    app.mainloop()
